# 레이아웃 — 헤더 / 사이드바 (layout)

> `src/features/header/`
> 전역 레이아웃 컴포넌트. 인증 상태(`useAuthStore`)와 현재 라우트에 따라 표시 여부 / 활성 탭 결정.

## 작업 이력

> 레이아웃 피처는 별도 스토어·서비스 없음 (인증 상태: `useAuthStore` / 라우팅: React Router `useLocation`).

| 날짜 | 디자인 | 컴포넌트 | 스토어 | 서비스 |
|---|---|---|---|---|
| 2026-07-08 | | | — | — |
| 2026-07-09 | | | — | — |
| 2026-07-10 | | | — | — |
| 2026-07-15 | | | — | — |

---

## 브랜치 & 커밋 이력

| 브랜치 | 커밋 | 날짜 | 내용 |
|---|---|---|---|
| `feat/scaffold` | `4715bc7` | 2026-07-08 | `SearchBar.tsx` 컴포넌트 분리 |
| `feat/scaffold` | `8f09267` | 2026-07-08 | axios 기반 HTTP 클라이언트 및 모듈 확장 타입 추가 |
| `feat/header` | `d8773ef` | 2026-07-08 | feat: 사이드바 구현 |
| `feat/header` | `6e126c7` `5870886` | 2026-07-08 | feat: 사이드바 |
| `feat/route` | `0602938` | 2026-07-09 | feat: `SideBarTab.tsx` 컴포넌트 분리 |
| `feat/route` | `05cd33e` | 2026-07-09 | feat: 라우트 설정 |
| `feat/route` | `9cbe919` | 2026-07-09 | feat: 사이드바 적용 |
| `feat/route` | `6626137` | 2026-07-09 | feat: 네비게이션 적용 |
| `feat/header` (PR #8) | `14beb71` | 2026-07-10 | fix: 사이드바 텍스트 밑줄 제거 |
| `fix/sidebar-report-active` | `8320f6c` | 2026-07-15 | fix: 리포트 목록 하위 경로에서도 사이드바 탭 active 처리 |
